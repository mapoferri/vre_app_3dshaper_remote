name = "biobb_3dshaper"
__all__ = ["dshaper"]
__version__ = "1.0.0"
